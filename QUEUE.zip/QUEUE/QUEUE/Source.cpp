#include <iostream>
using namespace std;
struct node
{
	int info;
	struct node *next;
};
struct queue
{
	node* Head;
	node* Tail;
};
node* createnode(int x)
{
	node *p = new node;
	if (p == NULL)
		return NULL;
	else
	{
		p->info = x;
		p->next = NULL;
		return p;
	}
}
void Push(queue &q, node *p)
{
	if (q.Head == NULL)
	{
		q.Head = p;
		q.Tail = p;
	}
	else
	{
		q.Tail->next = p;
		q.Tail = p;
	}
}
void Nhap(queue &q)
{
	int n;
	q.Head = NULL;
	q.Tail = NULL;
	cout << "Nhap so luong phan tu:";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		int x;
		cout << "Nhap phan tu thu " << i + 1 << ":";
		cin >> x;
		node *p = createnode(x);
		Push(q, p);
	}
}
bool Pop(queue &q, int &x)
{
	node *p;
	if (q.Head == NULL)
		return false;
	else
	{
		p = q.Head;
		x = p->info;
		q.Head = q.Head->next;
		if (q.Head == NULL)
			q.Tail = NULL;
		p->next = NULL;
		delete p;
		return true;
	}
}
void Xuat(queue &q)
{
	int x;
	while (Pop(q, x) == true)
	{
		cout << x << ", ";
	}
}
int main()
{
	queue q;
	Nhap(q);
	Xuat(q);
	system("pause");
	return 0;
}
#include <iostream>
#include <string>
using namespace std;

struct thongtin
{
	string tennhahang;
	int danhgia;
	float khoangcach;
};
struct Node
{
	thongtin info;
	struct Node *pnext;
};
struct List
{
	Node *phead;
	Node *ptail;
};
Node *createNode(thongtin x)
{
	Node *p;
	p = new Node;
	p->info = x;
	p->pnext = NULL;
	return p;
}
void createList(List &l)
{
	l.phead = NULL;
	l.ptail = NULL;
}
void addhead(List &l, Node *p)
{
	if (l.phead = NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		p->pnext = l.phead;
		l.phead = p;
	}
}
void addtail(List &l, Node *p)
{
	if (l.phead == NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		l.ptail->pnext = p;
		l.ptail = p;
	}
}
void Nhap(List &l)
{
	int n;
	cout << "n=";
	cin >> n;
	thongtin x;
	Node *p;
	createList(l);
	p = new Node;
	for (int i = 0; i < n; i++)
	{
		cout << "\nNhap ten nha hang: ";
		cin.ignore();
		getline(cin, x.tennhahang);
		cout << "\nMuc do danh gia: ";
		cin >> x.danhgia;
		cout << "\nKhoang cach: ";
		cin >> x.khoangcach;
		p = createNode(x);
		addtail(l, p);
	}
}
void HV(thongtin &a, thongtin &b)
{
	thongtin tam;
	tam = a;
	a = b;
	b = tam;
}
void Sapxep(List &l)
{
	Node *p, *q, *maxi;

	p = l.phead;
	while (p != l.ptail)
	{
		q = p->pnext;
		maxi = p;
		while (q != NULL)
		{
			if (q->info.danhgia > maxi->info.danhgia)
				HV(q->info, maxi->info);
			else
				if (p->info.danhgia == maxi->info.danhgia)
				{
					if (q->info.khoangcach < maxi->info.khoangcach)
						HV(q->info, maxi->info);
				}
			q = q->pnext;
		}
		p = p->pnext;
		cout << 1 << " ";
	}
}
void Xuat(List l)
{
	Node *p = l.phead;
	while(p!=NULL)
	{
		cout << "\nTen nha hang: " << p->info.tennhahang;
		cout << "\nDanh gia: " << p->info.danhgia;
		cout << "\nKhoang cach: " << p->info.khoangcach<<endl;
		p = p->pnext;
	}
}
int main()
{
	List l;
	createList(l);
	Nhap(l);
	Sapxep(l);
	Xuat(l);
	system("pause");
	return 0;
}


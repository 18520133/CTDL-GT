#include <iostream>
using namespace std;
struct node
{
	int data;
	struct node *pnext;
};
typedef struct node NODE;
struct stack
{
	NODE *phead;
};
typedef struct stack STACK;
void createStack(STACK &s)
{
	s.phead = NULL;
}
NODE *createNode(int x)
{
	NODE *p;
	p = new NODE;
	if (p == NULL) 
		return NULL;
	else
	{
		p->data = x;
		p->pnext = NULL;
		return p;
	}
}
void push(STACK &s, NODE *p)
{
	if (s.phead == NULL)
	{
		s.phead = p;
	}
	else
	{
		p->pnext = s.phead;
		s.phead = p;
	}
}
void Nhap(STACK &s)
{
	int n;
	int x;
	cout << "Nhap so phan tu: ";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "NHap phan tu thu " << i + 1 << " :";
		cin >> x;
		NODE *p = createNode(x);
		push(s, p);
	}
}
void pop(STACK &s, int &x)
{
	NODE *p;
	if (s.phead = NULL)
	{
		p = s.phead;
		x = p->data;
		s.phead = s.phead->pnext;
		delete p;
	}
	return;
}
void Xuat(STACK &s)
{
	int x;
		for (NODE *p = s.phead; p != NULL; p=p->pnext)
		{
			pop(s, x);
			cout << x << " ";
		}
}
int main()
{
	STACK s;
	Nhap(s);
	Xuat(s);
	system("pause");
	return 0;
}

#include <iostream>
using namespace std;
struct node
{
	int key;
	struct node *pleft;
	struct node *pright;
};
typedef node *tree;
node *createnode(int x)
{
	node *p = new node;
	if (p == NULL)
		exit(1);
	else
	{
		p->key = x;
		p->pleft = NULL;
		p->pright = NULL;
	}
	return p;
}
void createtree(tree &t)
{
	t = NULL;
}
int insertnode(tree &t, int x)
{
	if (t)
	{
		if (t->key == x)
			return 0;
		if (t->key > x)
			return insertnode(t->pleft, x);
		else
			return insertnode(t->pright, x);
	}
	t = new node;
	if (t == NULL)
		return -1;
	t->key = x;
	t->pleft = t->pright = NULL;
	return 1;
}
int nutM(tree t, int muc, int k)
{
	if (t != NULL)
	{
		if (muc == k)
			return 1;
		else
		{

			return nutM(t->pleft, muc, k + 1) + nutM(t->pright, muc, k + 1);
		}
	}
	else
		return 0;
}
int main()
{
	tree t;
	createtree(t);
	int x;
	while (1)
	{
		cin >> x;
		if (x == 0)
			break;
		insertnode(t, x);
	}
	int a[100], k = 0;
	for (int i = 0; i < 100; i++)
	{
		cin >> a[i];
		if (a[i] == 0)
			break;
		k++;
	}
	for (int i = 0; i < k; i++)
	{
		cout << nutM(t, a[i], 0) << endl;
	}
	system("pause");
	return 0;
}
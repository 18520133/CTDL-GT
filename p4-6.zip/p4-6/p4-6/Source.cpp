#include <iostream>
using namespace std;
struct node
{
	int info,dem;
	struct node *left;
	struct node *right;
};
node *createnode(int x)
{
	node *p = new node;
	p->dem = 1;
	p->info = x;
	p->left = NULL;
	p->right = NULL;
	return p;
}
void add(node *&t, node *p)
{
	if (t == NULL)
		t = p;
	else
	{
		if (p->info > t->info)
			add(t->right, p);
		else
			if (p->info < t->info)
				add(t->left, p);
			else
				t->dem++;
	}
}
void enter(node *&t)
{
	int n,x;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> x;
		node *p = createnode(x);
		add(t, p);
	}
}
void NLR(node *&t)
{
	if (t != NULL)
	{
		for (int i=0;i<t->dem;i++)
			cout << t->info << " ";
		NLR(t->left);
		NLR(t->right);
	}
}
int main()
{
		node *t;
		t = NULL;
		enter(t);
		NLR(t);
		system("pause");
		return 0;
}
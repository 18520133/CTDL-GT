#include <iostream>
using namespace std;
struct node
{
	int info;
	struct node *left;
	struct node *right;
};
node *createnode(int x)
{
	node *p = new node;
	p->info = x;
	p->left = NULL;
	p->right = NULL;
	return p;
}
void add(node *&t, node *p)
{
	if (t == NULL)
		t = p;
	else
	{
		if (p->info > t->info)
			add(t->right, p);
		else
			if (p->info < t->info)
				add(t->left, p);
	}
}
void enter(node *&t)
{
	int n;
	cin >> n;
	int x;
	for (int i = 0; i < n; i++)
	{
		cin >> x;
		node *p = createnode(x);
		add(t, p);
	}
}
int cao(node *t)
{
	if (t == NULL)
		return 0;
	int a = cao(t->left);
	int b = cao(t->right);
	if (a > b)
		return (a + 1);
	return (b + 1);
}
int main()
{
	node *t;
	t = NULL;
	enter(t);
	cout << cao(t) - 1;
	return 0;
}
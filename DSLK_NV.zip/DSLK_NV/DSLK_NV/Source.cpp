#include <iostream>
#include <string>
using namespace std;
struct ngaythangnam
{
	int dd, mm, yy;
};
typedef struct thongtin
{
	string hoten;
	ngaythangnam ngaysinh;
	float luong;
	int gioitinh;
}thongtin;
typedef struct NV
{
	thongtin info;
	struct NV *pnext;
}NV;
typedef struct DSNV
{
	NV *phead;
	NV *ptail;
}DSNV;
NV *createNV(thongtin x)
{
	NV *p;
	p = new NV;
	if (p == NULL)
		return NULL;
	p->info = x;
	p->pnext = NULL;
	return p;
}
void createDSNV(DSNV &l)
{
	l.phead = NULL;
	l.ptail = NULL;
}
void addhead(DSNV &l, NV *p)
{
	if (l.phead == NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		p->pnext = l.phead;
		l.phead = p;
	}
}
void Nhap(DSNV &l)
{
	int n;
	cout << "Nhap n: ";
	cin >> n;
	thongtin x;
	NV *k;
	for (int i = 0; i < n; i++)
	{
		cout << "Ho ten: ";
		cin.ignore();
		getline(cin, x.hoten);
		cout << "\nNgay thang nam sinh: ";
		cin >> x.ngaysinh.dd>>x.ngaysinh.mm>>x.ngaysinh.yy;
		cout <<" \nLuong: ";
		cin >> x.luong;
		cout << "\nGioi tinh: ";
		cin >> x.gioitinh;
		k = createNV(x);
		addhead(l, k);
	}
}
void XuatNV(NV *k)
{
	cout << "Ho ten: " << k->info.hoten;
	cout << "\nNgay thang nam: " << k->info.ngaysinh.dd << "/" << k->info.ngaysinh.mm << "/" << k->info.ngaysinh.yy ;
	cout << "\nLuong: " << k->info.luong;
	cout << "\nGioi tinh: ";
	if (k->info.gioitinh == 1)
		cout << "Nam";
	else
		cout << "Nu";
}
void XuatDSNV(DSNV &l)
{
	NV *p = new NV;
	p = l.phead;
	while (p != NULL)
	{
		XuatNV(p);
		p = p->pnext;
	}
}
void XuatNVtren40t(DSNV &l)
{
	cout << "\nDanh sach Nv tren 40t :" << endl;
	for (NV *p = l.phead; p!=NULL; p = p->pnext)
	{
		if (2019 - (p->info.ngaysinh.yy) > 40)
		{
			XuatNV(p);
			cout << endl;
		}
	}
}
int Luong1tr(DSNV &l)
{
	int dem = 0;
	for (NV *p = l.phead; p->pnext != NULL; p = p->pnext)
		if (p->info.luong > 1000000)
			dem = dem++;
	return dem;
}
void HV(thongtin &a, thongtin &b)
{
	thongtin tam = a;
	a = b;
	b = tam;
}
void Sapxepnamsinh(DSNV &l)
{
	NV *q, *p = l.phead, *max;
	while (p != l.ptail)
	{
		max = p;
		q = p->pnext;
		while (q != NULL)
		{
			if (q->info.ngaysinh.yy > max->info.ngaysinh.yy)
				max = q;
			q = q->pnext;
		}
		HV(max->info, p->info);
		p = p->pnext;
	}
}
int main()
{
	DSNV l;
	createDSNV(l);
	Nhap(l);
	XuatDSNV(l);
	XuatNVtren40t(l);
	cout << "\nSo NV luong tren 1tr: "<<Luong1tr(l);
	Sapxepnamsinh(l);
	XuatDSNV(l);
	system("pause");
	return 0;
}
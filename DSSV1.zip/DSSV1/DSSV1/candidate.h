#pragma once
#include<string>
#include<iostream>

using namespace std;

class Candidate
{
private:
	string HoTen;
	int Mssv;
	int d, m, y;
	float fToan;
	float fVan;
	float fAnh;
public:
	void Nhap();
	void Xuat();
	Candidate();
	Candidate(Candidate &a);
	string getHoTen();
	int getMssv();
	float getToan()
	{
		return fToan;
	}
	float getVan()
	{
		return fVan;
	}
	float getAnh()
	{
		return fAnh;
	}
	void setToan(float x)
	{
		fToan = x;
	}
	void setVan(float x)
	{
		fVan = x;
	}
	void setAnh(float x)
	{
		fAnh = x;
	}
	bool KT();
	~Candidate();
};


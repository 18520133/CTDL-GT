#include "DSSV.h"
#include <iostream>

using namespace std;


DSSV::DSSV()
{
}


DSSV::~DSSV()
{
}
void DSSV::Nhap()
{
	cout << "Nhap so luong sinh vien: ";
	cin >> n;
	arr = new Candidate[n + 1];
	for (int i = 0; i < n; i++)
	{
		cout << "\nNhap sinh vien thu " << i + 1;
		arr[i].Nhap();
	}

}
void DSSV::Xuat()
{
	cout << "\nDanh sach sinh vien ";
	for (int i = 0; i < n; i++)
	{
		cout << "Sinh vien thu " << i + 1;
		arr[i].Xuat();
	}
}
void DSSV::Check()
{
	for (int i = 0; i < n; i++)
	{
		bool Check = arr[i].KT();
		if (Check)
		{
			cout << "\nSinh vien co tong diem > 15 ";
			arr[i].Xuat();
		}
	}
}
#include "Candidate.h"
#include <iostream>

using namespace std;


Candidate::Candidate()
{
}
void Candidate::Nhap()
{
	cin.ignore();
	cout << "\nNhap Ho va Ten: ";
	getline(cin, HoTen);
	cout << "\nNhap MSSV: ";
	cin >> Mssv;
	cout << "\nNhap ngay thang nam sinh ";
	cin >> d >> m >> y;
	cout << "\nNhap diem Toan = ";
	cin >> fToan;
	cout << "\nNhap diem Van = ";
	cin >> fVan;
	cout << "\nNhap diem Anh = ";
	cin >> fAnh;
}
void Candidate::Xuat()
{
	cout << "\n-Ho va Ten: " << HoTen;
	cout << "\n-MSSV: " << Mssv;
	cout << "\n-Ngay thang nam sinh: " << d << "/" << m << "/" << y;
	cout << "\n-Toan = " << fToan;
	cout << "\n-Van = " << fVan;
	cout << "\n-Anh = " << fAnh;
}

bool Candidate::KT()
{
	float tong = fToan + fVan + fAnh;
	if (tong > 15) return 1;
	return 0;
}

Candidate::~Candidate()
{
}
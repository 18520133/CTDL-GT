#include <iostream>
#include <stdio.h>
#include <string.h>
using namespace std;

struct quanlisv
{
	int mssv;
	string hoten[50];
	int y;
	int gioitinh;
	float dtb;
};

void nhapds(quanlisv sv[], int &n)
{
	cout << "Nhap so sv: ";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "NHap thong tin sv " << i + 1 << endl;
		cout << "MSSV :";
		cin >> sv[i].mssv;
		cout << " Nhap ho ten: ";
		cin.ignore();
		cin.getline(sv[i].hoten, 50);
		cout << "Nam sinh: ";
		cin >> sv[i].y;
		cout << "Gioi tinh: ";
		cin >> sv[i].gioitinh;
		cout << "DTB: ";
		cin >> sv[i].dtb;
	}
}

void xuatds(quanlisv sv[],int n)
{	for (int i=0; i<n; i++)
	{
		cout << "SV thu " << i + 1 << endl;
		cout << "MSSV: " << sv[i].mssv<<endl;
		cout << "Ho ten: " << sv[i].hoten << endl;
		cout << "Gioi tinh: ";
		if (sv[i].gioitinh = 1)
			cout << "Nu" << endl;
		else 
			cout << "Nam"<<endl;
		cout << "DTB: " << endl;
	}
}

void timtensv(quanlisv sv[], string ten, int n)
{
	for (int i=0; i<n; i++)
	{
		if (sv[i].hoten==ten)
			cout << sv[i].hoten;
	}
}

void maxdtb(quanlisv sv[], int n)
{
	float max = sv[0].dtb;
	for (int i = 0; i < n; i++)
	{
		if(sv[i].dtb>max)
		{
			max = sv[i].dtb;
		cout << "sv co dtb cao nhat: " << sv[i].hoten;
		}
	}
}
int main()
{
	quanlisv sv[100];
	int n;
	cout << "n=";
	cin >> n;
	string ten;
	cin.ignore();
	cin.getline(ten,100);
	nhapds(sv, n);
	xuatds(sv, n);
	timtensv(sv, ten, n);
	maxdtb(sv, n);
	return 0;
}

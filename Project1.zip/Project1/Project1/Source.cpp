#include <iostream>
#include <stdio.h>
using namespace std;
struct node
{
	int info;
	node *pnext;
};
struct list
{
	node *phead;
	node *ptail;
};
node* createnode(int x)
{
	node *p;
	p = new node;
	if (p == NULL) exit(1);
	p->info = x;
	p->pnext = NULL;
	return p;
}
void createlist(list &l)
{
	l.phead = NULL;
	l.ptail = NULL;
}
void addhead(list &l, node* p)
{
	if (l.phead == NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		p->pnext = l.phead;
		l.phead = p;
	}
}
void nhap(list &l)
{
	int x, n;
	node *k;
	cout << "n=";
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cout << "x=";
		cin >> x;
		k = createnode(x);
		addhead(l, k);
	}
}
void xuat(list l)
{
	node *p=l.phead;
	while (p != NULL)
	{
		cout << p->info;
		p = p->pnext;
	}
}
int main()
{
	list l;
	createlist(l);
	nhap(l);
	xuat(l);
	system("pause");
	return 0;
}
#include <iostream>
using namespace std;
struct Node
{
	int info;
	struct Node *pnext;
};
struct List
{
	Node *phead;
	Node *ptail;
};
Node *createNode(int x)
{
	Node *p;
	p = new Node;
	if (p == NULL)
		return NULL;
	p->info = x;
	p->pnext = NULL;
	return p;
}
void createList(List &l)
{
	l.phead = l.ptail = NULL;
}
void addtail(List &l,Node *p)
{
	if (l.phead == NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		l.ptail->pnext = p;
		l.ptail = p;
	}
}
void addhead(List &l, Node *p)
{
	if (l.phead == NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		p->pnext = l.phead;
		l.phead = p;
	}
}
int removehead(List &l, int &x)
{
	Node *p;
	if (l.phead != NULL)
	{
		p = l.phead;
		x = p->info;
		l.phead = l.phead->pnext;
		delete p;
		if (l.phead = NULL)
			l.ptail = NULL;
		return 1;
	}
	return 0;
}
void quicksort(List &l)
{
	if (l.phead == NULL)
		return;
	List l1, l2, b;
	createList(l1);
	createList(l2);
	createList(b);
	int x, t;
	removehead(l, x);
	while (l.phead)
	{
		removehead(l, tmp);

	}
}

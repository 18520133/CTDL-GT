#include <iostream>
#include <algorithm>
using namespace std;
void HV(int a, int b)
{
	int temp;
	temp = a;
	a = b;
	b = temp;
}
void selectionsort(int A[])
{
	int max;
	for (int i = 0; i < 8; i++)
	{
		max = i;
		for (int j = i+1; j < 9; j++)
				if (A[j] > A[max])
					max = j;
			HV(A[i], A[max]);
		}
}
void insertionsort(int A[])
{
	for (int i = 1; i < 9; i++)
	{
		int e = A[i];
		int k;
		for (k = i - 1; k > -1; k--)
		{
			if (A[k] < e) break;
			A[k + 1] = A[k];
		}
		A[k + 1] = e;
	}
}
int main()
{
	int A[] = { 8,2,1,9,4,5,7,6,3 };
	cout << "Selection Sort: ";
	selectionsort(A);
	for (int i = 0; i < 9; i++)
		cout << A[i] << " ";
	cout << "\nInsertion Sort :";
	insertionsort(A);
	for (int i = 0; i < 9; i++)
		cout << A[i] << " ";
	system("pause");
	return 0;
}
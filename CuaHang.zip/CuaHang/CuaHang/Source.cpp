#include <iostream>
#include <string>
using namespace std;

struct thongtin
{
	string tencuahang;
	int somathang;
	int danhgia;
	float khoangcach;
};
struct Node
{
	thongtin info;
	struct Node *pnext;
};
struct List
{
	Node *phead;
	Node *ptail;
};
Node *createNode(thongtin x)
{
	Node *p;
	p = new Node;
	if (p == NULL)
		return NULL;
	p->info = x;
	p->pnext = NULL;
	return p;
}
void createList(List &l)
{
	l.phead = NULL;
	l.ptail = NULL;
}
void addtail(List &l,Node *p)
{
	if (l.phead = NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		l.ptail->pnext = p;
		l.ptail = p;
	}
}
void Nhap(List &l)
{
	int n;
	cout << "n=";
	cin >> n;
	thongtin x;
	Node *p;
	p = new Node;
	createList(l);
	for (int i = 0; i < n; i++)
	{
		cout << "\nTen cua hang: ";
		cin.ignore();
		getline(cin, x.tencuahang);
		cout << "\nSo mat hang: ";
		cin >> x.somathang;
		cout << "\nMuc do danh gia: ";
		cin >> x.danhgia;
		cout << "\nKhoang cach: ";
		cin >> x.khoangcach;
		p =createNode(x);
		addtail(l, p);
	}
}
int main()
{
	List l;
	createList(l);
	Nhap(l);
	system("pause");
	return 0;

}
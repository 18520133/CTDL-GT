#include <iostream>
using namespace std;

typedef struct tagNode
{
	int info;
	struct tagNode *pnext;
}Node;
typedef struct tagList
{
	Node *phead;
}List;
Node *CreateNode(int x)
{
	Node *p;
	p = new Node;
	if (p == NULL)
		return NULL;
	p->info = x;
	p->pnext = NULL;
	return p;
}
void CreateList(List &l)
{
	l.phead = NULL;
}
bool KT(List &l,int x)
{
	for (Node *p = l.phead; p->pnext != NULL; p->pnext)
	{
		if (p->info == x)
			cout << "Nhap lai: ";
		return 0;
	}
	return 1;
}
void AddHead(List &l, Node *p)
{
	if (l.phead == NULL)
	{
		l.phead = p;
	}
	else
	{
		p->pnext = l.phead;
		l.phead = p;
	}
}
void Nhap(List &l)
{
	int n;
	cout << "Nhap so luong phan tu: ";
	cin >> n;
	int b;
	for (int i = 1; i <= n; i++)
	{
		cout << "b=";
		cin >> b;
		Node *p = CreateNode(b);
		AddHead(l, p);
	}
}
bool SNT(int x)
{
	int k = 0;
	for (int i = 2; i <= x; i++)
	{
		if (x%i == 0)
			k++;
	}
	if (k == 1) return 1;
	else
		return 0;
}
void KTM(List &l)
{
	int a=0;
	int m;
	cout << "m=";
	cin >> m;
	for (Node *p = l.phead; p != NULL; p=p->pnext)
	{
		if (p->info < m)
		{
			if (SNT(p->info) == 1)
				a += 1;
		}
	}
	cout << a;
}
int RemoveHead(List &l)
{
	Node *p;
	if (l.phead != NULL)
	{
		p = l.phead;
		l.phead = l.phead->pnext;
		delete p;
		return 1;
	}
	return 0;
}

int main()
{
	List l;
	CreateList(l);
	Nhap(l);
	KTM(l);
	cout << "\nXoa 5 phan tu cuoi danh sach: ";
	for (int i=1; i<=4;i++)
		RemoveHead(l);
	system("pause");
	return 0;
}
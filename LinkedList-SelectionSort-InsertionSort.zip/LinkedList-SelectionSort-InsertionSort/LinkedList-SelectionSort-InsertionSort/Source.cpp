#include <iostream>
using namespace std;
struct Node
{
	int info;
	struct Node *pnext;
};
struct List
{
	Node *phead;
	Node *ptail;
};
void CreateList(List &l)
{
	l.phead = NULL;
	l.ptail = NULL;
}
Node *CreateNode(int x)
{
	Node *p = new Node;
	p->info = x;
	p->pnext = NULL;
	return p;
}
void addHead(List &l, Node *p)
{
	if (l.phead == NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		p->pnext = l.phead;
		l.phead = p;
	}
}
void Nhap(List &l)
{
	int n;
	cout << "n=";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		int x;
		cout << "Nhap phan tu thu " << i + 1 << " :";
		cin >> x;
		Node *p = CreateNode(x);
		addHead(l, p);
	}
}

void HV(int &a, int &b)
{
	int tam;
	tam = a;
	a = b;
	b = tam;
}
void SelectionSort(List &l)
{
	Node *p = l.phead;
	while (p->pnext != NULL)
	{
		Node *min = p;
		Node *q = p->pnext;
		while (q != NULL)
		{
			if (min->info > q->info)
				min = q;
			q = q->pnext;

		}
		HV(min->info, p->info);
		p->pnext;
	}
}
void Delete(List &l, Node *e)
{
	if (e == l.phead)
	{
		l.phead = l.phead->pnext;
		delete(e);
	}
	else
	{
		Node *preE = l.phead;
		while ((preE != NULL) && (preE->pnext != e))
		{
			preE = preE->pnext;
		}
		preE->pnext = e->pnext;
		delete e;
	}
}
void InsertionSort(List &l)
{
	Node *p = l.phead;
	p = p->pnext;
	while (p != NULL)
	{
		Node *min = CreateNode(p->info);
		Node *q = l.phead;
		Node *preq = NULL;
		while ((q->info < min->info) && (q != NULL))
		{
			preq = q;
			q = q->pnext;
		}
		if (q != p)
		{
			Node *tam = p;
			p = p->pnext;
			Delete(l, tam);
			if (preq = NULL)
			{
				addHead(l, min);
			}
			else
			{
				preq->pnext = min;
				min->pnext = q;
			}
		}
		else
		{
			p = p->pnext;
		}
	}
}
void Xuat(List &l)
{
	Node *p = l.phead;
	while (p != NULL)
	{
		cout << p->info << " ";
		p = p->pnext;
	}
}
int main()
{
	List l;
	CreateList(l);
	Nhap(l);
	//SelectionSort(l);
	//cout << "SelectionSort : ";
	//Xuat(l);
	cout << "\nInsertionSort : ";
	InsertionSort(l);
	Xuat(l);
	system("pause");
	return 0;
}

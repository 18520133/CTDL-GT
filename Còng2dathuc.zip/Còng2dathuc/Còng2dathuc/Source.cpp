#include <iostream>
using namespace std;

typedef struct donthuc
{
	int somu;
	int heso;
}donthuc;
typedef struct dathuc
{
	donthuc *info;
	struct dathuc *pnext;
}dathuc;
typedef struct tagList
{
	dathuc *phead;
	dathuc *ptail;
}List;
void createList(List &l)
{
	l.phead = NULL;
	l.ptail = NULL;
}
donthuc *createdonthuc(int x,int a)
{
	donthuc *p;
	p = new donthuc;
	if (p == NULL)
		return NULL;
	p->heso = a;
	p->somu = x;
	return p;
}
dathuc *createdathuc(donthuc *x)
{
	dathuc *p;
	p = new dathuc;
	if (p == NULL)
		return NULL;
	p->info = x;
	p->pnext = NULL;
	return p;
}
void addhead(List &l, dathuc *p)
{
	if (l.phead == NULL)
	{
	l.phead = p;
	l.ptail = l.phead;
	}
	else
	{
		p->pnext = l.phead;
		l.phead = p;
	}
}
void Nhapdonthuc(List &l)
{
	int x,a,n;
	donthuc *q;
	dathuc *k;
	cout << "n=";
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cout << "so mu =";
		cin >> x;
		cout << "he so =";
		cin >> a;
		q = createdonthuc(x, a);
		k = createdathuc(q);
		addhead(l, k);
	}
}
void Xuatdathuc(List &l)
{
	for (dathuc *k = l.phead; k->pnext != NULL; k = k->pnext)
	{
		cout << k->info->heso << "*X^" << k->info->somu << "+";
	}
}
List Cong(List l1, List l2)
{
	List l=l1;
	for (dathuc *p = l2.phead; p != NULL; p = p->pnext)
		for (dathuc *q = l.phead; q != NULL; q = q->pnext)
			if (p->info->somu == q->info->somu)
				q->info->heso = q->info->heso + p->info->heso;
	for (dathuc *p = l2.phead; p != NULL; p = p->pnext)
	{
		int i = 0;
		for (dathuc *q = l.phead; q != NULL; q = q->pnext)
			if (p->info->somu == q->info->somu)
				i = 1;
		if (i == 0)
		{
			donthuc *x = createdonthuc(p->info->heso,p->info->somu);
			dathuc *k = createdathuc(x);
			addhead(l, k);
		}
	}
	return l;
}
int main()
{
	List l1, l2;
	Nhapdonthuc(l1);
	Nhapdonthuc(l2);
	
	Xuatdathuc(l1);
	Xuatdathuc(l2);
	//system("pause");
	return 0;

}


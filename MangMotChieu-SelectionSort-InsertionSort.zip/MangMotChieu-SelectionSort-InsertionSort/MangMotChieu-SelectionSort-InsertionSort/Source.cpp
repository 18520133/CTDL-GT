#include <iostream>
using namespace std;
void HV(int &a,int &b)
{
	int tam;
	tam = a;
	a = b;
	b = tam;
}
void selectionsort(int *a, int n)
{
	int min;
	for (int i = 0; i < n; i++)
	{
		min = i;
		for (int j = i + 1; j <= n; j++)
				if (a[min] > a[j])
					min = j;
		HV(a[i],a[min]);
	}
}
void insertionsort(int *a, int n)
{
	for (int i = 0; i < n; i++)
	{
		int x = a[i];
		int j = i - 1;
		while (a[j] >= a[i])
		{
			a[j + 1] = a[j];
			j--;
		}
		a[j+1] = x;
	}
}
int main()
{
	int *a;
	int n;
	cout << "n=";
	cin >> n;
	a = new int(n + 1);
	for (int i = 0; i < n; i++)
	{
		cout << "Nhap phan tu thu a[" << i + 1 << "]=";
		cin >> a[i];
	}
	cout << "\nSelectionSort: ";
	selectionsort(a, n);
	for (int i = 0; i < n; i++)
		cout << a[i] << " ";
	cout << "\nInsertionSort: ";
	insertionsort(a, n);
	for (int i = 0; i < n; i++)
		cout << a[i] << " ";
	system("pause");
	return 0;
}
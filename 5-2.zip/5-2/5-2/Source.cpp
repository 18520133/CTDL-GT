#include <iostream>
using namespace std;
struct node
{
	int key;
	struct node *pleft;
	struct node *pright;
};
typedef node *tree;
node *createnode(int x)
{
	node *p = new node;
	if (p == NULL)
		exit(1);
	else
	{
		p->key = x;
		p->pleft = NULL;
		p->pright = NULL;
	}
	return p;
}
void createtree(tree &t)
{
	t = NULL;
}
int insertnode(tree &t, int x)
{
	if (t)
	{
		if (t->key == x)
			return 0;
		if (t->key > x)
			return insertnode(t->pleft, x);
		else
			return insertnode(t->pright, x);
	}
	t = new node;
	if (t == NULL)
		return -1;
	t->key = x;
	t->pleft = t->pright = NULL;
	return 1;
}
void replace(tree &p, tree &t)
{
	if (t->pleft != NULL)
		replace(p, t->pleft);
	else
	{
		p->key = t->key;
		p = t;
		t = t->pright;
	}
}
void deletenode(tree &t, int x)
{
	if (t != NULL)
	{
		if (t->key < x)
			deletenode(t->pright, x);
		else
		{
			if (t->key > x)
				deletenode(t->pleft, x);
			else
			{
				node *p;
				p = t;
				if (t->pleft == NULL)
					t = t->pright;
				else
				{
					if (t->pright == NULL)
						t = t->pleft;
					else
						replace(p, t->pright);
				}
				delete p;
			}
		}
	}
	else cout << "0";
}
void NLR(tree t)
{
	if (t != NULL)
	{
		cout << t->key << " ";
		NLR(t->pleft);
		NLR(t->pright);
	}
}
void NRL(tree t)
{
	if (t != NULL)
	{
		cout << t->key << " ";
		NRL(t->pright);
		NRL(t->pleft);
	}
}
void LNR(tree t)
{
	if (t != NULL)
	{
		LNR(t->pleft);
		cout << t->key << " ";
		LNR(t->pright);
	}
}
void RNL(tree t)
{
	if (t != NULL)
	{
		RNL(t->pright);
		cout << t->key << " ";
		RNL(t->pleft);
	}
}
void LRN(tree t)
{
	if (t != NULL)
	{
		LRN(t->pleft);
		LRN(t->pright);
		cout << t->key << " ";
	}
}
void RLN(tree t)
{
	if (t != NULL)
	{
		RLN(t->pright);
		RLN(t->pleft);
		cout << t->key << " ";
	}
}
int main()
{
	tree t;
	createtree(t);
	int x;
	while (1)
	{
		cin >> x;
		if (x == 0)
			break;
		insertnode(t, x);
	}
	int a[100], k = 0;
	for (int i = 0; i < 100; i++)
	{
		cin >> a[i];
		if (a[i] == 0)
			break;
		k++;
	}
	for (int i = 0; i < k; i++)
	{
		deletenode(t, a[i]);
	}
	cout << "\nNLR ";
	NLR(t);
	cout << "\nNRL ";
	NRL(t);
	cout << "\nLNR ";
	LNR(t);
	cout << "\nRNL ";
	RNL(t);
	cout << "\nLRN ";
	LRN(t);
	cout << "\nRLN ";
	RLN(t);
	system("pause");
	return 0;
}
#include <iostream>
using namespace std;
void quicksort(int *a, int l, int r)
{
	int i = l;
	int j = r;
	int midle = a[(l + r) / 2];
	while (i <= j)
	{
		while (a[i] < midle) i++;
		while (a[j] > midle) j--;
		if (i <= j)
		{
			int temp = a[i];
			a[i] = a[j];
			a[j] = temp;
			i++;
			j--;
		}
		if (i < r)
			quicksort(a, i, r);
		if (j > l)
			quicksort(a, l, j);
	}
}
int main()
{
	int *a;
	int n, i=0;
	cout << "n=";
	cin >> n;
	a = new int[n+1];
	cout << endl;
	for (int i = 0; i < n; i++)
	{
		cout << "a[" << i + 1 << "]=";
		cin >> a[i];
	}
	quicksort(a, 0, n-1);
	for (int i = 0; i < n; i++)
	{
		cout << a[i] << " ";
	}
	system("pause");
	return 0;
}
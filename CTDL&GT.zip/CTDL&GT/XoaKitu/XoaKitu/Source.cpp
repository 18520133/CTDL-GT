#include <iostream>
#include <stdio.h>
#include<string>
using namespace std;
struct node
{
	char data;
	struct node *pNext;
};
typedef struct node NODE;
struct stack
{
	NODE *pHead;
};
typedef struct stack STACK;
void CreateStack(STACK &s)
{
	s.pHead = NULL;
}
NODE *CreateNode(char x)
{
	NODE *p = new NODE;
	if (p == NULL)
	{
		return NULL;
	}
	p->data = x;
	p->pNext = NULL;
	return p;
}
bool IsEmpty(STACK s)
{
	if (s.pHead == NULL)
	{
		return true;
	}
	return false;
}
void Push(STACK &s, NODE *p)
{
	if (IsEmpty(s) == true)
	{
		s.pHead = p;
	}
	else
	{
		p->pNext = s.pHead;
		s.pHead = p;
	}
}
char Pop(STACK &s)
{
	if (IsEmpty(s) == true)
	{
		return 1;
	}
	char x;
	NODE *p;
	p = s.pHead;
	x = p->data;
	s.pHead = s.pHead->pNext;
	delete p;
	return x;
}
/*char Top(STACK s)
{

	return s.pHead->data;

}*/

void Input(STACK &s)
{
	string x;
	NODE *p = new NODE;
	cout << "\n Nhap vao x:";
	cin.ignore();
	getline(cin, x);
	int dai = x.length();
	for (int i = 0; i < dai; i++)
	{
		if (x[i] != '*')
		{
			p = CreateNode(x[i]);
			Push(s, p);
		}
		else
		{
			cout << Pop(s);
		}
	}
}
void Output(STACK s)
{
	for (NODE *p = s.pHead; p != NULL; p = p->pNext)
	{
		cout << " " << p->data;
	}
}
int main()
{
	STACK s;
	CreateStack(s);
	string x;
	Input(s);
	system("pause");
	return 0;
}
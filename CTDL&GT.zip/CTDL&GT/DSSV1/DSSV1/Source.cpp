#include "DSSV.h"
#include<iostream>

using namespace std;

int main()
{
	DSSV a;
	a.Nhap();
	a.Xuat();
	a.Check();
	system("pause");
	return 0;
}
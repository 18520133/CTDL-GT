#pragma once
#include"Candidate.h"
class DSSV
{
private:
	int n;
	Candidate *arr;
public:
	void Nhap();
	void Xuat();
	void Check();
	DSSV();
	~DSSV();
};


#include <iostream>
using namespace std;
struct Node
{
	string info;
	struct Node *pNext;
}
struct List
{
	Node *pHead;
	Node *pTail;
};
Node* CreateNode(String x)
{
	Node *p;
	p = new Node;
	if (p == NULL)
		return NULL;
	p->info = x;
	p->pNext = NULL;
	return p;
}
void createList(List &l)
{
	l.pHead = NULL;
	l.pTail = NULL;
}

void addtail(List &l, Node *p)
{
	if (l.pHead == NULL)
	{
		l.pHead = p;
		l.pTail = l.pHead;
	}
	else
	{
		l.pTail->pNext = p;
		l.pTail = p;
	}
}

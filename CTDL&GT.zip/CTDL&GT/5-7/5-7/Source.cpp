#include <iostream>
using namespace std;
struct node
{
	int key;
	struct node *pleft;
	struct node *pright;
};
typedef node *tree;
node *createnode(int x)
{
	node *p = new node;
	if (p == NULL)
		exit(1);
	else
	{
		p->key = x;
		p->pleft = NULL;
		p->pright = NULL;
	}
	return p;
}
void createtree(tree &t)
{
	t = NULL;
}
int insertnode(tree &t, int x)
{
	if (t)
	{
		if (t->key == x)
			return 0;
		if (t->key > x)
			return insertnode(t->pleft, x);
		else
			return insertnode(t->pright, x);
	}
	t = new node;
	if (t == NULL)
		return -1;
	t->key = x;
	t->pleft = t->pright = NULL;
	return 1;
}
int nut(tree t)
{
	if (t != NULL)
	{
		return nut(t->pleft) + nut(t->pright) + 1;

	}
	else
		return 0;
}
int main()
{
	tree t;
	createtree(t);
	int x;
	while (1)
	{
		cin >> x;
		if (x == 0)
			break;
		insertnode(t, x);
	}
	cout << nut(t);
	system("pause");
	return 0;
}
﻿#include <iostream>
#include <string>
using namespace std;
struct day
{
	int d;
	int m;
	int y;
};
struct NV
{
	string Name;
	day Birth;
	float Salary;
	int gender; //0:Nu; 1:Nam
};
struct node
{
	NV info;
	struct node *next;
};
struct list
{
	node *Head;
	node *Tail;
};
void initList(list &l)
{
	l.Head = l.Tail = NULL;
}
node* createnode(NV x)
{
	node *p = new node;
	if (p == NULL)
		return NULL;
	else
	{
		p->info = x;
		p->next = NULL;
		return p;
	}
}
void AddHead(list &l, node *p)
{
	if (l.Head == NULL)
	{
		l.Head = p;
		l.Tail = p;
	}
	else
	{
		p->next = l.Head;
		l.Head = p;
	}
}
void NhapNV(NV &x)
{
	cout << "Nhap ho ten:";
	cin.ignore();
	getline(cin, x.Name);
	cout << "Nhap ngay thang nam sinh:";
	cin >> x.Birth.d >> x.Birth.m >> x.Birth.y;
	cout << "Nhap tien luong:";
	cin >> x.Salary;
	cout << "Nhap gioi tinh (0:nu; 1:nam):";
	cin >> x.gender;
}
void Nhap(list &l, int &n)
{
	cout << "Nhap so luong nhan vien:";
	cin >> n;
	NV x;
	for (int i = 0; i < n; i++)
	{
		NhapNV(x);
		node *p = createnode(x);
		AddHead(l, p);
	}
}
void xuatday(day a)
{
	cout << a.d << "/" << a.m << "/" << a.y;
}
void XuatNV(NV x)
{
	cout << "\nHo ten:" << x.Name;
	cout << "\nNgay thang nam sinhL:";
	xuatday(x.Birth);
	cout << "\nTien luong:" << x.Salary;
	if (x.gender == 1)
		cout << "\nGioi tinh: Nam";
	else cout << "\nGioi tinh:Nu";
}
void Xuat(list l, int n)
{
	int i = 1;
	node *p = l.Head;
	while (i <= n)
	{
		XuatNV(p->info);
		p = p->next;
		i = i + 1;
	}
}
void DeleteNV(list &l, int &n)
{
	string s;
	cout << "\nNhap ten can xoa:";
	cin.ignore();
	getline(cin, s);
	node *p = l.Head;
	for (int i = 0; i < n; i++)
	{
		if (p->info.Name.compare(s) == 0)
			if (p == l.Head)
			{
				l.Head = p->next;
				p->next = NULL;
				delete p;
				n = n - 1;
			}
			else
			{
				node *q = l.Head;
				while (q != NULL)
				{
					if (q->next == p)
					{
						q->next = p->next;
						p->next = NULL;
						delete p;
						n = n - 1;
					}
					q = q->next;
				}
			}
		p = p->next;
	}
}
void NV40(list l, int n)
{
	node *p = l.Head;
	while (p != NULL)
	{
		if (2019 - p->info.Birth.y >= 40)
			XuatNV(p->info);
		p = p->next;
	}
}
int Dem(list l)
{
	int d = 0;
	node *p = l.Head;
	while (p != NULL)
	{
		if (p->info.Salary >= 1000000)
			d++;
		p = p->next;
	}
	return d;
}
void SortTuoi(list l)
{
	node *p = l.Head;
	while (p != NULL)
	{
		node *q = p->next;
		while (q != NULL)
		{
			if (p->info.Birth.y < q->info.Birth.y)
			{
				NV x = p->info;
				p->info = q->info;
				q->info = x;
			}
			q = q->next;
		}
		p = p->next;
	}
}
int main()
{
	int n;
	list l;
	initList(l);
	Nhap(l, n);
	cout << "\n--------------------------------------------------";
	cout << "\nNhung nhan vien >=40 tuoi:";
	NV40(l, n);
	cout << endl;
	cout << "\n----------------------------------------------------";
	cout << "\nSo nhan vien co luong >=1000000đ:" << Dem(l) << endl;
	cout << "\n----------------------------------------------------";
	SortTuoi(l);
	Xuat(l, n);
	cout << "\n----------------------------------------------------";
	string s;
	DeleteNV(l, n);
	Xuat(l, n);
	system("pause");
	return 0;
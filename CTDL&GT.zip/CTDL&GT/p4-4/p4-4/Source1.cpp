#include <iostream>
using namespace std;
struct node
{
	int info;
	struct node *left;
	struct node *right;
};
node *createnode(int x)
{
	node *p = new node;
	p->info = x;
	p->left = NULL;
	p->right = NULL;
	return p;
}
void add(node *&t, node *p)
{
	if (t == NULL)
		t = p;
	else
	{
		if (p->info > t->info)
			add(t->right, p);
		else
			add(t->left, p);
	}
}
void replace(node *&p, node *&t)
{
	if (t->left != NULL)
		replace(p, t->left);
	else
	{
		p->info = t->info;
		p = t;
		t = t->right;
	}
}
void xoa(node *&t)
{
	if (t == NULL) return;
	if (t->right != NULL)
		xoa(t->right);
	else
	{
		node *p;
		p = t;
		if (t->left == NULL) t = t->right;
		else
		{
			if (t->right == NULL) t = t->left;
			else replace(p, t->right);
		}
		delete p;
	}
}
void enter(node *&t)
{
	int x, id;
	do
	{
		cin >> id;
		if (id == 1)
		{
			cin >> x;
			node *p = createnode(x);
			add(t, p);
		}
		if (id == 2)
		{
			xoa(t);
		}
	} while (id != -1);
}
void LNR(node *&t)
{
	if (t == NULL) return;
	if (t->left != NULL)
		LNR(t->left);
	cout << t->info << " ";
	if (t->right != NULL)
		LNR(t->right);
}
int main()
{
	node *t;
	t = NULL;
	enter(t);
	LNR(t);

	return 0;
}
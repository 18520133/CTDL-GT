#include <iostream>
using namespace std;
struct node
{
	int key;
	struct node *pleft;
	struct node *pright;
};
typedef node *tree;
node *createnode(int x)
{
	node *p = new node;
	if (p == NULL)
		exit(1);
	else
	{
		p->key = x;
		p->pleft = NULL;
		p->pright = NULL;
	}
	return p;
}
void createtree(tree &t)
{
	t = NULL;
}
int insertnode(tree &t, int x)
{
	if (t)
	{
		if (t->key == x)
			return 0;
		if (t->key > x)
			return insertnode(t->pleft, x);
		else
			return insertnode(t->pright, x);
	}
	t = new node;
	if (t == NULL)
		return -1;
	t->key = x;
	t->pleft = t->pright = NULL;
	return 1;
}
void NLR(tree t)
{
	if (t != NULL)
	{
		cout << t->key << " ";
		NLR(t->pleft);
		NLR(t->pright);
	}
}
void NRL(tree t)
{
	if (t != NULL)
	{
		cout << t->key << " ";
		NRL(t->pright);
		NRL(t->pleft);
	}
}
void LNR(tree t)
{
	if (t != NULL)
	{
		LNR(t->pleft);
		cout << t->key << " ";
		LNR(t->pright);
	}
}
void RNL(tree t)
{
	if (t != NULL)
	{
		RNL(t->pright);
		cout << t->key << " ";
		RNL(t->pleft);
	}
}
void LRN(tree t)
{
	if (t != NULL)
	{
		LRN(t->pleft);
		LRN(t->pright);
		cout << t->key << " ";
	}
}
void RLN(tree t)
{
	if (t != NULL)
	{
		RLN(t->pright);
		RLN(t->pleft);
		cout << t->key << " ";
	}
}
int main()
{
	node *t;
	createtree(t);
	int x;
	while (1)
	{
		cin >> x;
		if (x == 0)
			break;
		insertnode(t, x);
	}
	cout << "NLR ";
	NLR(t);
	cout << "\nNRL ";
	NRL(t);
	cout << "\nLNR ";
	LNR(t);
	cout << "\nRNL ";
	RNL(t);
	cout << "\nLRN ";
	LRN(t);
	cout << "\nRLN ";
	RLN(t);
	system("pause");
	return 0;
}

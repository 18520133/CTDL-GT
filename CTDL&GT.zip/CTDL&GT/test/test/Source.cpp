#include <iostream>
using namespace std;
void selectionsort(int a[], int n)
{
	int min;
	for (int i = 0; i < n - 1; i++)
	{
		min = i;
		for (int j = 0; j < n; j++)
			if (a[j] < a[min])
				min = j;
		swap(a[i], a[min]);
	}
}
/*int main()
{
	int *a;
	int n;
	cout << "n=";
	cin >> n;
	a = new int[n];
	for (int i = 0; i < n; i++)
	{
		cout << "a[" <<i<< "]=";
		cin >> a[i];
	}
	selectionsort(a, n);
	for (int i = 0; i < n; i++)
		cout << a[i] << " ";
	system("pause");
	return 0;
}*/
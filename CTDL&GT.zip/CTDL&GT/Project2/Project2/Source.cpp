#include <iostream>
#include <stdio.h>
using namespace std;
struct node
{
	int info;
	node *pnext;
};
struct list
{
	node *phead;
	node *ptail;
};
node* createnode(int x)
{
	node *p;
	p = new node;
	if (p == NULL) exit(1);
	p->info = x;
	p->pnext = NULL;
	return p;
}
void createlist(list &l)
{
	l.phead = NULL;
	l.ptail = NULL;
}
void addhead(list &l, node* p)
{
	if (l.phead == NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		p->pnext = l.phead;
		l.phead = p;
	}
}
void addtail(list &l, node*p)
{
	if (l.phead == NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		l.ptail->pnext = p;
		l.ptail = p;
	}
}
void insertafterq(list &l, node* p, node *q)
{
	if (q != NULL)
	{
		p->pnext = q->pnext;
		q->pnext = p;
		if (l.ptail == q)
			l.ptail = p;
	}
	else
		addhead(l, q);
}
int removehead(list &l)
{
	node* p;
	if (l.phead != NULL)
	{
		p = l.phead;
		l.phead = l.phead->pnext;
		if (l.phead == NULL)
			l.ptail = NULL;
		delete p;
		return 1;
	}
	return 0;
}
int removeafterq(list &l, node* q)
{
	node *p;
	if (q != NULL)
	{
		p = q->pnext;
		if (p != NULL)
		{
			if (p == l.ptail)
				l.ptail = q;
			q->pnext = p->pnext;
			delete p;
		}
		return 1;
	}
	else
		return 0;
}
int removex(list &l, int x)
{
	node*p, *q = NULL;
	p = l.phead;
	while ((p != NULL) && (p->info != x))
	{
		q = p;
		p = p->pnext;
	}
	if (p == NULL)
		return 0;
	if (q != NULL)
		removeafterq(l, q);
	else
		removehead(l);
	return 1;
}
node* search(list l, int x)
{
	node *p;
	p = l.phead;
	while ((p != NULL) && (p->info != x))
		p = p->pnext;
	return p;
}
void removelist(list &l)
{
	node *p;
	while (l.phead != NULL)
	{
		p = l.phead;
		l.phead = p->pnext;
		delete p;
	}
}

void nhap(list &l)
{
	int x, n;
	node *k;
	cout << "n=";
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cout << "x=";
		cin >> x;
		k = createnode(x);
		addtail(l, k);
	}
}
void xuat(list l)
{
	node *p = l.phead;
	while (p != NULL)
	{
		cout << p->info;
		p = p->pnext;
	}
}
int main()
{
	list l;
	createlist(l);
	nhap(l);
	xuat(l);
	//----------------------------------------
	cout << "/nchen nut co gia tri x sau node co gia tri y:";
	int x, y;
	cout << "/nNhap x:";
	cin >> x;
	cout << "/nNhap y:";
	cin >> y;
	node *q;
	q = search(l, y);
	node *p = createnode(x);
	insertafterq(l, p, q);
	xuat(l);
	//-----------------------------------------
	cout << "/nXoa nut dau tien:";
	x = removehead(l);
	if (x == 1) xuat(l);
	//-----------------------------------------
	cout << "/nXoa phan tu sau x:";
	cout << "Nhap x:";
	cin >> x;
	q = createnode(x);
	x = removeafterq(l, q);
	if (x == 1)
		xuat(l); 
	//------------------------------------------
	cout << "/nXoa phan tu x:";
	cout << "Nhap x=";
	cin >> x;
	y = removex(l, x);
	if (y == 1)
		xuat(l);
	system("pause");
	return 0;
}
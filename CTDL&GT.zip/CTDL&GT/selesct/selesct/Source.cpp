#include<iostream>
using namespace std;

struct Node
{
	int info;
	struct Node *pNext;
};
struct tagList
{
	Node *pHead;
	Node *pTail;
};
Node *CreateNode(int x)
{
	Node *p;
	p = new Node;
	if (p == NULL)
		exit(1);
	p->info = x;
	p->pNext = NULL;
	return p;
}
void CreateList(tagList &l)
{
	l.pHead = NULL;
	l.pTail = NULL;
}
void addHead(tagList &l, Node *p)
{
	if (l.pHead == NULL)
	{
		l.pHead = p;
		l.pTail = p;
	}
	else
	{
		p->pNext = l.pHead->pNext;
		l.pHead = p;
	}
}
void addTail(tagList &l, Node *p)
{
	if (l.pHead == NULL)
	{
		l.pHead = p;
		l.pTail = p;
	}
	else
	{
		l.pTail->pNext = p;
		l.pTail = p;
	}
}
int RemoveHead(tagList &l, int &x)
{
	if (l.pHead == NULL)
		return -1;
	else
	{
		x = l.pHead->info;
		Node *p = l.pHead;
		l.pHead = p->pNext;
		p->pNext = NULL;
		delete p;
		return x;
	}
}
void QuichSort(tagList &l)
{
	if (l.pHead->pNext == NULL) return;
	tagList A1, A2;
	CreateList(A1);
	CreateList(A2);
	int x, tmp;
	RemoveHead(l, x);
	while(l.pHead)
	{
		RemoveHead(l, tmp);
		if (tmp < x)
			addTail(A1, CreateNode(tmp));
		else
			addTail(A2, CreateNode(tmp));
	}
	QuichSort(A1);QuichSort(A2);
	if (A1.pHead) {
		A1.pTail->pNext = A2.pHead;
		l.pHead = A1.pHead;
	}
	else {
		l.pHead = A2.pHead;
	}

	if (A2.pHead) {
		l.pTail = A2.pTail;
	}
	else {
		l.pTail = A1.pTail;
	}
}
void output(tagList &a) {
	for (Node* p = a.pHead; p!=NULL; p=p->pNext)
	{
		cout << p->info;
	}
}
int main() {
	tagList a;
	CreateList(a);
	int n;
	cin >> n;
	for (int i = 0; i <n; i++)
	{
		int t;
		cin >> t;
		Node* c =CreateNode(t);
		addTail(a, c);
	}
	QuichSort(a);
	output(a);
	system("pause");
	return 0;
}
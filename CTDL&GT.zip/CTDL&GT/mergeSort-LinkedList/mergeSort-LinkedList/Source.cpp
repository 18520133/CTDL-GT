#include <iostream>
using namespace std;

struct Node
{
	int info;
	struct Node *pnext;
};
struct List
{
	Node *phead;
	Node *ptail;
};
Node *createNode(int x)
{
	Node *p;
	p = new Node;
	if (p == NULL)
		return NULL;
	p->info = x;
	p->pnext = NULL;
	return p;
}
void createList(List &l)
{
	l.phead = l.ptail = NULL;
}
void addtail(List &l, Node *p)
{
	if(l.phead == NULL)
	{
		l.phead = p;
		l.ptail = l.phead;
	}
	else
	{
		l.ptail->pnext = p;
		l.ptail = p;
	}
}
void partition(List &l, List &l1, List &l2)
{
	int lane = 0;
	createList(l1);
	createList(l2);
	while (l.phead)
	{
		Node *p = l.phead;
		l.phead = p->pnext;
		p->pnext = NULL;
		if (lane) addtail(l2, p);
		else addtail(l1, p);
		lane = !lane;
	}
	l.ptail = NULL;
}
void merge(List &l1, List &l2, List &l)
{
	Node *p;
	while (l1.phead&&l2.phead)
	{
		if (l1.phead->info < l2.phead->info)
		{
			p = l1.phead;
			l1.phead = p->pnext;
		}
		else
		{
			p = l2.phead;
			l2.phead = p->pnext;
		}
		p->pnext = NULL;
		addtail(l, p);
	}
	while (l1.phead)
	{
		p = l1.phead;
		l1.phead = p->pnext;
		p->pnext = NULL;
		addtail(l, p);
	}
	while (l2.phead)
	{
		p = l2.phead;
		l2.phead = p->pnext;
		p->pnext = NULL;
		addtail(l, p);
	}
}
void mergesort(List &l)
{
	if (!l.phead) return;
	List l1, l2;
	partition(l, l1, l2);
	mergesort(l1);
	mergesort(l2);
	merge(l1, l2, l);
}
int main()
{
	int x, n;
	Node *p;
	List l;
	createList(l);
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> x;
		p = createNode(x);
		addtail(l, p);
	}
	mergesort(l);
	for (Node *p = l.phead; p != NULL; p = p->pnext)
	{
		cout << p->info<<" ";
	}
	system("pause");
	return 0;
}
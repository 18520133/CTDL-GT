#include <iostream>
using namespace std;
struct node
{
	int key;
	struct node *pleft;
	struct node *pright;
};
typedef node *tree;
node *createnode(int x)
{
	node *p = new node;
	if (p == NULL)
		exit(1);
	else
	{
		p->key = x;
		p->pleft = NULL;
		p->pright = NULL;
	}
	return p;
}
void createtree(tree &t)
{
	t = NULL;
}
int insertnode(tree &t, int x)
{
	if (t)
	{
		if (t->key == x)
			return 0;
		if (t->key > x)
			return insertnode(t->pleft, x);
		else
			return insertnode(t->pright, x);
	}
	t = new node;
	if (t == NULL)
		return -1;
	t->key = x;
	t->pleft = t->pright = NULL;
	return 1;
}
int nutbac1(tree t)
{
	if (t != NULL)
	{
		if (t->pleft == NULL && t->pright != NULL || t->pright == NULL && t->pleft != NULL)
			return 1 + nutbac1(t->pleft)+nutbac1(t->pright);
		else
			return nutbac1(t->pleft) + nutbac1(t->pright);
	}
	else
		return 0;
}
int main()
{
	tree t;
	createtree(t);
	int x;
	while (1)
	{
		cin >> x;
		if (x == 0)
			break;
		insertnode(t, x);
	}
	cout << nutbac1(t);
	system("pause");
	return 0;
}